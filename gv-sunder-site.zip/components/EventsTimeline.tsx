const events = [
  { date: "15 AUG", title: "Public Meeting", location: "Andhra Pradesh" },
  { date: "20 AUG", title: "Graduate Interaction", location: "To be announced" },
  { date: "24 AUG", title: "Press Interaction", location: "To be announced" },
];

export default function EventsTimeline() {
  return (
    <section id="events" className="bg-white py-16 sm:py-20">
      <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8">
        <p className="text-sm font-bold uppercase tracking-widest text-amber-600">Schedule</p>
        <h2 className="mt-3 text-3xl font-black sm:text-4xl">Public Events</h2>
        <div className="mt-10 space-y-4">
          {events.map((event) => (
            <article key={event.title} className="flex gap-5 rounded-2xl border border-slate-200 p-5">
              <div className="flex h-16 w-16 shrink-0 flex-col items-center justify-center rounded-xl bg-slate-900 text-xs font-bold text-white">
                {event.date}
              </div>
              <div>
                <h3 className="font-bold">{event.title}</h3>
                <p className="mt-1 text-sm text-slate-500">{event.location}</p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}