export default function About() {
  return (
    <section id="about" className="bg-white py-16 sm:py-20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl">
          <p className="text-sm font-bold uppercase tracking-widest text-amber-600">About</p>
          <h2 className="mt-3 text-3xl font-black tracking-tight sm:text-4xl">G. V. Sunder</h2>
          <p className="mt-5 text-lg leading-8 text-slate-600">
            This section is ready for a verified biography, professional background,
            public service experience and other factual public information.
          </p>
          <div className="mt-8 grid gap-4 sm:grid-cols-3">
            {["Biography", "Public Record", "Constituency"].map((item) => (
              <div key={item} className="rounded-2xl border border-slate-200 p-5">
                <div className="text-sm font-bold text-slate-900">{item}</div>
                <p className="mt-2 text-sm leading-6 text-slate-500">
                  Add verified information here.
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}