"use client";

import { useState } from "react";

export default function PublicContact() {
  const [tab, setTab] = useState<"issue" | "contact">("issue");

  return (
    <section id="contact" className="bg-white py-16 sm:py-20">
      <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <p className="text-sm font-bold uppercase tracking-widest text-amber-600">Public Contact</p>
          <h2 className="mt-3 text-3xl font-black sm:text-4xl">Submit Information or an Issue</h2>
          <p className="mx-auto mt-4 max-w-xl text-sm leading-6 text-slate-500">
            This demo form is frontend-only. Connect it to a secure server-side endpoint before collecting real submissions.
          </p>
        </div>

        <div className="mt-10 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
          <div className="grid grid-cols-2 border-b border-slate-200">
            <button onClick={() => setTab("issue")} className={`px-4 py-4 text-sm font-bold ${tab === "issue" ? "border-b-2 border-amber-600 text-amber-600" : "text-slate-500"}`}>
              Voice an Issue
            </button>
            <button onClick={() => setTab("contact")} className={`px-4 py-4 text-sm font-bold ${tab === "contact" ? "border-b-2 border-amber-600 text-amber-600" : "text-slate-500"}`}>
              Contact
            </button>
          </div>

          <form onSubmit={(e) => e.preventDefault()} className="space-y-5 p-6 sm:p-8">
            <label className="block">
              <span className="mb-2 block text-sm font-semibold">Name</span>
              <input required className="w-full rounded-xl border border-slate-300 px-4 py-3" placeholder="Your name" />
            </label>

            <label className="block">
              <span className="mb-2 block text-sm font-semibold">Phone / WhatsApp</span>
              <input type="tel" className="w-full rounded-xl border border-slate-300 px-4 py-3" placeholder="Phone number" />
            </label>

            {tab === "issue" ? (
              <>
                <label className="block">
                  <span className="mb-2 block text-sm font-semibold">Category</span>
                  <select className="w-full rounded-xl border border-slate-300 px-4 py-3">
                    <option>Job / Employment</option>
                    <option>Education</option>
                    <option>Local Issue</option>
                    <option>Other</option>
                  </select>
                </label>
                <label className="block">
                  <span className="mb-2 block text-sm font-semibold">Description</span>
                  <textarea rows={5} className="w-full rounded-xl border border-slate-300 px-4 py-3" placeholder="Describe the issue" />
                </label>
                <label className="block">
                  <span className="mb-2 block text-sm font-semibold">Attachment</span>
                  <input type="file" className="w-full rounded-xl border border-slate-300 p-3 text-sm" />
                </label>
              </>
            ) : (
              <label className="block">
                <span className="mb-2 block text-sm font-semibold">Message</span>
                <textarea rows={5} className="w-full rounded-xl border border-slate-300 px-4 py-3" placeholder="Your message" />
              </label>
            )}

            <button type="submit" className="w-full rounded-xl bg-slate-900 px-5 py-3 font-bold text-white hover:bg-slate-800">
              Submit
            </button>

            <p className="text-xs leading-5 text-slate-500">
              Do not submit sensitive personal information. Add appropriate privacy, consent and data-retention notices before production use.
            </p>
          </form>
        </div>
      </div>
    </section>
  );
}