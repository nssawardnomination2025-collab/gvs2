"use client";

import { Menu, X } from "lucide-react";
import { useState } from "react";
import { en } from "@/content/en";
import { te } from "@/content/te";

export default function Header() {
  const [open, setOpen] = useState(false);
  const [telugu, setTelugu] = useState(false);
  const t = telugu ? te : en;

  const links = [
    [t.nav.about, "#about"],
    [t.nav.priorities, "#priorities"],
    [t.nav.media, "#media"],
    [t.nav.events, "#events"],
    [t.nav.contact, "#contact"],
  ];

  return (
    <header className="sticky top-0 z-50 border-b border-slate-200 bg-white/95 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        <a href="#" className="flex items-center gap-3" aria-label="G. V. Sunder home">
          <div className="flex h-10 w-10 items-center justify-center rounded-full bg-slate-900 font-bold text-amber-500">
            GV
          </div>
          <div>
            <div className="font-bold leading-none text-slate-900">G. V. Sunder</div>
            <div className="mt-1 text-[10px] uppercase tracking-wider text-slate-500">Graduate MLC</div>
          </div>
        </a>

        <nav className="hidden items-center gap-7 md:flex" aria-label="Primary">
          {links.map(([label, href]) => (
            <a key={href} href={href} className="text-sm font-medium text-slate-600 transition hover:text-amber-600">
              {label}
            </a>
          ))}
          <button
            type="button"
            onClick={() => setTelugu((v) => !v)}
            className="rounded-full border border-slate-300 px-3 py-1.5 text-sm font-semibold"
            aria-label="Switch language"
          >
            {telugu ? "English" : "తెలుగు"}
          </button>
        </nav>

        <button
          type="button"
          onClick={() => setOpen((v) => !v)}
          className="rounded-lg p-2 md:hidden"
          aria-label={open ? "Close navigation" : "Open navigation"}
          aria-expanded={open}
        >
          {open ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {open && (
        <div className="border-t border-slate-200 bg-white px-4 py-4 md:hidden">
          <nav className="flex flex-col gap-1" aria-label="Mobile">
            {links.map(([label, href]) => (
              <a
                key={href}
                href={href}
                onClick={() => setOpen(false)}
                className="rounded-lg px-3 py-3 text-sm font-medium hover:bg-slate-50"
              >
                {label}
              </a>
            ))}
            <button
              type="button"
              onClick={() => setTelugu((v) => !v)}
              className="mt-2 rounded-lg border border-slate-200 px-3 py-3 text-left text-sm font-semibold"
            >
              {telugu ? "English" : "తెలుగు"}
            </button>
          </nav>
        </div>
      )}
    </header>
  );
}