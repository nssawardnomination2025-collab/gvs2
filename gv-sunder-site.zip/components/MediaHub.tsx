"use client";

import Image from "next/image";
import { useState } from "react";
import { X } from "lucide-react";

type MediaItem = {
  type: "All" | "Press" | "Videos" | "Photos";
  title: string;
  description: string;
  image?: string;
};

const items: MediaItem[] = [
  { type: "Press", title: "Public statement", description: "Replace with a verified press release." },
  { type: "Videos", title: "Interview", description: "Replace with an official video embed." },
  { type: "Photos", title: "Public meeting", description: "Replace with an appropriately licensed photograph.", image: "/images/meeting-01.svg" },
];

const filters: MediaItem["type"][] = ["All", "Press", "Videos", "Photos"];

export default function MediaHub() {
  const [filter, setFilter] = useState<MediaItem["type"]>("All");
  const [lightbox, setLightbox] = useState<string | null>(null);

  const visible = filter === "All" ? items : items.filter((item) => item.type === filter);

  return (
    <section id="media" className="bg-slate-50 py-16 sm:py-20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <p className="text-sm font-bold uppercase tracking-widest text-amber-600">Media</p>
        <h2 className="mt-3 text-3xl font-black sm:text-4xl">News & Media</h2>

        <div className="mt-7 flex flex-wrap gap-2">
          {filters.map((item) => (
            <button
              key={item}
              onClick={() => setFilter(item)}
              className={`rounded-full px-4 py-2 text-sm font-bold ${
                filter === item ? "bg-slate-900 text-white" : "bg-white text-slate-600 border border-slate-200"
              }`}
            >
              {item}
            </button>
          ))}
        </div>

        <div className="mt-8 grid gap-5 md:grid-cols-3">
          {visible.map((item) => (
            <article key={item.title} className="overflow-hidden rounded-2xl border border-slate-200 bg-white">
              {item.image ? (
                <button onClick={() => setLightbox(item.image!)} className="block w-full text-left">
                  <Image src={item.image} alt="" width={900} height={500} className="aspect-video w-full object-cover" />
                </button>
              ) : (
                <div className="flex aspect-video items-center justify-center bg-slate-200 text-sm font-bold text-slate-500">
                  {item.type}
                </div>
              )}
              <div className="p-5">
                <span className="text-xs font-bold uppercase tracking-wider text-amber-600">{item.type}</span>
                <h3 className="mt-2 font-bold">{item.title}</h3>
                <p className="mt-2 text-sm leading-6 text-slate-500">{item.description}</p>
              </div>
            </article>
          ))}
        </div>
      </div>

      {lightbox && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/80 p-4" role="dialog" aria-modal="true">
          <button
            onClick={() => setLightbox(null)}
            className="absolute right-5 top-5 rounded-full bg-white p-2 text-slate-900"
            aria-label="Close image"
          >
            <X size={22} />
          </button>
          <Image src={lightbox} alt="" width={1200} height={800} className="max-h-[85vh] w-auto rounded-xl object-contain" />
        </div>
      )}
    </section>
  );
}