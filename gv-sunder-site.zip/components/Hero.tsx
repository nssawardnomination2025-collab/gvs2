import Image from "next/image";
import { en } from "@/content/en";

export default function Hero() {
  return (
    <section className="overflow-hidden bg-slate-950">
      <div className="mx-auto grid max-w-7xl items-center gap-10 px-4 py-14 sm:px-6 lg:grid-cols-2 lg:px-8 lg:py-24">
        <div className="max-w-2xl">
          <div className="mb-5 inline-flex rounded-full border border-amber-500/30 bg-amber-500/10 px-4 py-2 text-xs font-bold uppercase tracking-wider text-amber-400">
            {en.hero.eyebrow}
          </div>
          <h1 className="text-4xl font-black tracking-tight text-white sm:text-5xl lg:text-6xl">
            {en.hero.title}
          </h1>
          <p className="mt-5 max-w-xl text-lg leading-8 text-slate-300">
            {en.hero.description}
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <a href="#priorities" className="rounded-xl bg-amber-600 px-5 py-3 font-bold text-white hover:bg-amber-500">
              {en.hero.primary}
            </a>
            <a href="#contact" className="rounded-xl border border-white/20 px-5 py-3 font-bold text-white hover:bg-white/10">
              {en.hero.secondary}
            </a>
          </div>
        </div>

        <div className="relative mx-auto w-full max-w-lg">
          <div className="absolute -inset-4 rounded-3xl bg-amber-500/10 blur-2xl" />
          <div className="relative overflow-hidden rounded-3xl border border-white/10 bg-slate-900">
            <Image
              src="/images/candidate.svg"
              alt="Candidate portrait placeholder"
              width={900}
              height={1100}
              priority
              className="h-auto w-full object-cover"
              sizes="(max-width: 1024px) 90vw, 45vw"
            />
          </div>
        </div>
      </div>
    </section>
  );
}