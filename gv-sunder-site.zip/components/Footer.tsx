export default function Footer() {
  return (
    <footer className="bg-slate-950 text-slate-300">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid gap-10 md:grid-cols-3">
          <div>
            <div className="text-xl font-black text-white">G. V. Sunder</div>
            <p className="mt-3 max-w-sm text-sm leading-6 text-slate-400">
              Official informational website. Verify public information before publication.
            </p>
          </div>
          <div>
            <h3 className="font-bold text-white">Contact</h3>
            <div className="mt-3 space-y-2 text-sm text-slate-400">
              <p>Campaign / Public Office</p>
              <p>Andhra Pradesh, India</p>
              <p>Phone: +91 XXXXX XXXXX</p>
              <p>Email: contact@example.com</p>
            </div>
          </div>
          <div>
            <h3 className="font-bold text-white">Online</h3>
            <div className="mt-3 flex flex-wrap gap-4 text-sm">
              <a href="#" className="hover:text-amber-400">X</a>
              <a href="#" className="hover:text-amber-400">Facebook</a>
              <a href="#" className="hover:text-amber-400">YouTube</a>
              <a href="#" className="hover:text-amber-400">WhatsApp</a>
            </div>
          </div>
        </div>
        <div className="mt-10 border-t border-white/10 pt-6 text-xs text-slate-500">
          © {new Date().getFullYear()} G. V. Sunder. All rights reserved.
        </div>
      </div>
    </footer>
  );
}