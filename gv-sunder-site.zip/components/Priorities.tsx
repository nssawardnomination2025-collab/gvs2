const priorities = [
  ["01", "Education & Graduate Issues", "Information concerning employment, job notifications, higher education and university reforms."],
  ["02", "Regional Development", "Public information concerning infrastructure, civic development and regional priorities across Andhra Pradesh."],
  ["03", "Youth & Public Leadership", "Information about mentorship, youth development, civic participation and transparent public administration."],
];

export default function Priorities() {
  return (
    <section id="priorities" className="bg-slate-50 py-16 sm:py-20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <p className="text-sm font-bold uppercase tracking-widest text-amber-600">Priorities</p>
        <h2 className="mt-3 text-3xl font-black sm:text-4xl">Areas of Public Focus</h2>
        <div className="mt-10 grid gap-5 md:grid-cols-3">
          {priorities.map(([number, title, text]) => (
            <article key={number} className="rounded-2xl border border-slate-200 bg-white p-7 shadow-sm">
              <div className="text-sm font-black text-amber-600">{number}</div>
              <h3 className="mt-5 text-xl font-bold">{title}</h3>
              <p className="mt-3 leading-7 text-slate-600">{text}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}