import Header from "@/components/Header";
import Hero from "@/components/Hero";
import About from "@/components/About";
import Priorities from "@/components/Priorities";
import EventsTimeline from "@/components/EventsTimeline";
import MediaHub from "@/components/MediaHub";
import PublicContact from "@/components/PublicContact";
import Footer from "@/components/Footer";

export default function Home() {
  return (
    <main>
      <Header />
      <Hero />
      <About />
      <Priorities />
      <EventsTimeline />
      <MediaHub />
      <PublicContact />
      <Footer />
    </main>
  );
}