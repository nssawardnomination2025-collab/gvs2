import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "G. V. Sunder | Graduate MLC",
  description:
    "Official informational website for G. V. Sunder, Graduate MLC candidate in Andhra Pradesh.",
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}