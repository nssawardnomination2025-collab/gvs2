export const en = {
  nav: {
    about: "About",
    priorities: "Priorities",
    media: "Media",
    events: "Events",
    contact: "Public Contact",
  },
  hero: {
    eyebrow: "Graduate MLC Candidate · Andhra Pradesh",
    title: "G. V. Sunder",
    description:
      "Public information about education, graduate issues, regional development, youth initiatives, public meetings and civic engagement.",
    primary: "View Priorities",
    secondary: "Submit an Issue",
  },
};